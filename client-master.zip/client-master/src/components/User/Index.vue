<template>
<div>
<h1>Get All Users</h1>
</div>
</temlate>
<script>
export default{


}
</script>
<style scoped>
</style>